/* global QUnit */

sap.ui.require(["rmtool1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
