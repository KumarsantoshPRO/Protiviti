sap.ui.define(function () {
	"use strict";

	return {

		removeZero: function (sValue) {
			debugger;

		}
	};

});